package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.R */
public final class C0265R {
    private C0265R() {
    }
}
