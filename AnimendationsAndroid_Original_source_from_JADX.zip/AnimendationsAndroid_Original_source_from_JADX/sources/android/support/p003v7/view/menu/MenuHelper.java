package android.support.p003v7.view.menu;

import android.support.p003v7.view.menu.MenuPresenter;

/* renamed from: android.support.v7.view.menu.MenuHelper */
interface MenuHelper {
    void dismiss();

    void setPresenterCallback(MenuPresenter.Callback callback);
}
